﻿using UnityEngine;
using System.Collections;

public class swipeBoard : MonoBehaviour {

	public bool zoomIn =false;
	public GameObject [] buttonList;
	public swipeBoardKey swipeBoardButton;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}

}
