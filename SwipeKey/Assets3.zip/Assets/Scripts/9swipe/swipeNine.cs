﻿using UnityEngine;
using System.Collections;
using TouchScript.Gestures;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Holoville.HOTween;

public class swipeNine: MonoBehaviour {
	
	public FlickGesture flick;// Use this for initialization
	public TapGesture tap;
	public InputField intext;
	public int buttonNumber;
	private const float tweenDuration = 0.03f;
	private const float tweenScale = 1.2f;
	private const float offset = 0.2f;
	
	void Start () {
		HOTween.Init ();
		flick.Flicked += HandleFlick;
		tap.Tapped += HandleTap;
		//intext = GameObject.Find ("InputField").GetComponentsInChildren<Text>()[1];
		intext = GameObject.Find ("theText").GetComponent<InputField>();
		
	}

	void HandleTap (object sender, System.EventArgs e)
	{
		switch (buttonNumber) {
			case 1:
				intext.text += "s";
				buttonAnimation(0,"s");
				break;
			case 2:
				intext.text += "g";
				buttonAnimation(0,"g");
				break;
			case 3:
				intext.text += "k";
				buttonAnimation(0,"k");
				break;
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	void HandleFlick(object sender, System.EventArgs e){
		switch (buttonNumber) 
		{
		case 1:
			if(Mathf.Abs(flick.ScreenFlickVector.x) * 0.41421356 > Mathf.Abs(flick.ScreenFlickVector.y)){	//right/left swipe
				if(flick.ScreenFlickVector.x > 0){	//right swipe
					intext.text += "d";
					buttonAnimation(0,"d");}
				else{	//left swipe
					intext.text += "a";
					buttonAnimation(1,"a");}
			}
			else if(Mathf.Abs(flick.ScreenFlickVector.x) * 2.41421356 < Mathf.Abs(flick.ScreenFlickVector.y)){	//up/down swipe
				if(flick.ScreenFlickVector.y > 0){	//up swipe
					intext.text += "w";
					buttonAnimation(2,"w");}
				else{	//down swipe
					intext.text += "x";
					buttonAnimation(3,"x");}
			}
			else{							//left/right-up/down
				if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y >= 0){	//right-up
					intext.text += "e";
					buttonAnimation(4,"e");}
				else if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y < 0){	//right-down
					intext.text += "c";
					buttonAnimation(5,"c");}
				else if(flick.ScreenFlickVector.x < 0 && flick.ScreenFlickVector.y >= 0){	//left-up
					intext.text += "q";
					buttonAnimation(6,"q");}
				else {	//left-down
					intext.text += "z";
					buttonAnimation(7,"z");}
			}
			break;
		case 2:
			if(Mathf.Abs(flick.ScreenFlickVector.x) * 0.41421356 > Mathf.Abs(flick.ScreenFlickVector.y)){	//right/left swipe
				if(flick.ScreenFlickVector.x > 0){	//right swipe
					intext.text += "h";
					buttonAnimation(0,"h");}
				else{	//left swipe
					intext.text += "f";
					buttonAnimation(1,"f");}
			}
			else if(Mathf.Abs(flick.ScreenFlickVector.x) * 2.41421356 < Mathf.Abs(flick.ScreenFlickVector.y)){	//up/down swipe
				if(flick.ScreenFlickVector.y > 0){	//up swipe
					intext.text += "t";
					buttonAnimation(2,"t");}
				else{	//down swipe
					intext.text += "b";
					buttonAnimation(3,"b");}
			}
			else{							//left/right-up/down
				if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y >= 0){	//right-up
					intext.text += "y";
					buttonAnimation(4,"y");}
				else if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y < 0){	//right-down
					intext.text += "n";
					buttonAnimation(5,"n");}
				else if(flick.ScreenFlickVector.x < 0 && flick.ScreenFlickVector.y >= 0){	//left-up
					intext.text += "r";
					buttonAnimation(6,"r");}
				else {	//left-down
					intext.text += "v";
					buttonAnimation(7,"v");}
			}
			break;
		case 3:
			if(Mathf.Abs(flick.ScreenFlickVector.x) * 0.41421356 > Mathf.Abs(flick.ScreenFlickVector.y)){	//right/left swipe
				if(flick.ScreenFlickVector.x > 0){	//right swipe
					intext.text += "l";
					buttonAnimation(0,"l");}
				else{	//left swipe
					intext.text += "j";
					buttonAnimation(1,"j");}
			}
			else if(Mathf.Abs(flick.ScreenFlickVector.x) * 2.41421356 < Mathf.Abs(flick.ScreenFlickVector.y)){	//up/down swipe
				if(flick.ScreenFlickVector.y > 0){	//up swipe
					intext.text += "i";
					buttonAnimation(2,"i");}
				else{	//down swipe
					intext.text += "p";
					buttonAnimation(3,"p");}
			}
			else{							//left/right-up/down
				if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y >= 0){	//right-up
					intext.text += "o";
					buttonAnimation(4,"o");}
				else if(flick.ScreenFlickVector.x >= 0 && flick.ScreenFlickVector.y < 0){	//right-down
					intext.text += "";
					buttonAnimation(5,"");}
				else if(flick.ScreenFlickVector.x < 0 && flick.ScreenFlickVector.y >= 0){	//left-up
					intext.text += "u";
					buttonAnimation(6,"u");}
				else {	//left-down
					intext.text += "m";
					buttonAnimation(7,"m");}
			}
			break;
		}

		
	}
	
	void buttonAnimation(int dir,string note){
		Vector3 oScale = transform.localScale;
		Vector3 oPosition = transform.position;
		Sequence buttonSequence = new Sequence ();
		buttonSequence.Append(HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("localScale", oScale * tweenScale)));
		buttonSequence.Append(HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("localScale", oScale)));
		switch(dir){
		case 0:
			buttonSequence.Insert(0,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", new Vector3(oPosition.x+offset,oPosition.y,oPosition.z))));	
			buttonSequence.Insert(tweenDuration,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", oPosition)));	
			break;
		case 1:
			buttonSequence.Insert(0,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", new Vector3(oPosition.x-offset,oPosition.y,oPosition.z))));	
			buttonSequence.Insert(tweenDuration,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", oPosition)));	
			break;
		case 2:
			buttonSequence.Insert(0,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", new Vector3(oPosition.x,oPosition.y+offset,oPosition.z))));	
			buttonSequence.Insert(tweenDuration,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", oPosition)));	
			break;
		case 3:
			buttonSequence.Insert(0,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", new Vector3(oPosition.x,oPosition.y-offset,oPosition.z))));	
			buttonSequence.Insert(tweenDuration,HOTween.To (transform, tweenDuration, new TweenParms ().Prop ("position", oPosition)));	
			break;
		}
		buttonSequence.Play ();
	}
	
}
